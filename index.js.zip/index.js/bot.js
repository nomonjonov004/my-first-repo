const ytdlpPath = 'C:\\Users\\acer\\AppData\\Local\\Programs\\Python\\Python312\\Scripts\\yt-dlp.exe';
exec(`"${ytdlpPath}" -o ${fileName} ${text}`, (error, stdout, stderr) => {
    if (error) {
        console.error(`Yuklab olishda xatolik: ${stderr}`);
        return bot.sendMessage(chatId, "Videoni yuklab olishda xatolik yuz berdi.");
    }

    bot.sendVideo(chatId, fileName)
        .then(() => {
            exec(`"${ytdlpPath}" -x --audio-format mp3 -o ${audioName} ${text}`, (error, stdout, stderr) => {
                if (error) {
                    console.error(`Audio olishda xatolik: ${stderr}`);
                    return bot.sendMessage(chatId, "Audioni olishda xatolik yuz berdi.");
                }

                bot.sendAudio(chatId, audioName)
                    .then(() => {
                        fs.remove(fileName, (err) => {
                            if (err) console.error(`Videoni o'chirishda xatolik: ${err}`);
                        });
                        fs.remove(audioName, (err) => {
                            if (err) console.error(`Audioni o'chirishda xatolik: ${err}`);
                        });
                    });
            });
        })
        .catch(err => {
            console.error("Videoni yuborishda xatolik:", err);
            bot.sendMessage(chatId, "Videoni yuborishda xatolik yuz berdi.");
        });
});